
function showSection(sectionId) 
{
    let sections = document.querySelectorAll(".section");
    sections.forEach(section => section.classList.add("hidden"));
    document.getElementById(sectionId).classList.remove("hidden");
}


function updateWiFi() 
{
    let ssid = document.getElementById("ssid").value;
    let password = document.getElementById("wifiPassword").value;
    alert(`WiFi actualizado: \nSSID: ${ssid} \nContraseña: ${password}`);
}


function restartRouter() 
{
    alert("🔄 Reiniciando el router...");
}


function logout() 
{
    alert("Cerrando sesión...");
    window.location.href = "inicio.html"; 
}
