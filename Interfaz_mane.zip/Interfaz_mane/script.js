function login() 
{
    var user = document.getElementById("username").value;
    var pass = document.getElementById("password").value;

    if (user === "admin" && pass === "admin") 
        { 
        alert("✅ Acceso concedido");
        window.location.href = "panel.html"; 
    } else 
    {
        document.getElementById("message").innerText = "❌ Credenciales incorrectas";
    }
}
